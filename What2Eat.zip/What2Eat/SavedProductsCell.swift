//
//  SavedProductsCell.swift
//  What2Eat
//
//  Created by sumanaswi on 05/11/24.
//

import UIKit

class SavedProductsCell: UITableViewCell {

    
    @IBOutlet weak var SavedProductsName: UILabel!
    @IBOutlet weak var SavedProductsImage: UIImageView!
    
    @IBOutlet weak var ScoreCircle: UIView!
    @IBOutlet weak var Scoretext: UILabel!
}
