//
//  NutritionCell.swift
//  What2Eat
//
//  Created by admin68 on 02/11/24.
//

import UIKit

class NutritionCell: UITableViewCell {

    @IBOutlet weak var NutrientLabel: UILabel!
    

    @IBOutlet weak var NutrientGrams: UILabel!
    
    @IBOutlet weak var NutritionProgress: UIProgressView!
}
