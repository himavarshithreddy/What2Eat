//
//  ExploreHeaderView.swift
//  What2Eat
//
//  Created by admin68 on 03/11/24.
//

import UIKit

class ExploreHeaderView: UICollectionReusableView {
        
    
}
