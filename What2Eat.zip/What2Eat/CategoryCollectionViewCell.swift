//
//  CategoryCollectionViewCell.swift
//  What2Eat
//
//  Created by admin68 on 02/11/24.
//

import UIKit

class CategoryCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var CategoryImage: UIImageView!
    
    @IBOutlet weak var CategoryName: UILabel!
}
