//
//  ViewController.swift
//  What2Eat
//
//  Created by admin68 on 23/10/24.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.fjmjyhj
    }


}

