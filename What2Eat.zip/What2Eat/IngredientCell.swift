//
//  IngredientCell.swift
//  What2Eat
//
//  Created by admin68 on 02/11/24.
//

import UIKit

class IngredientCell: UITableViewCell {


    @IBOutlet weak var ingredientLabel: UILabel!
    
    @IBOutlet weak var riskLevelLabel: UILabel!
    
    
}
