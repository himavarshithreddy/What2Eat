//
//  ExploreProductsCell.swift
//  What2Eat
//
//  Created by admin20 on 05/11/24.
//

import UIKit

class ExploreProductsCell: UITableViewCell {

   
    @IBOutlet weak var ExploreProductsImage: UIImageView!
    
    @IBOutlet weak var ExploreProductsName: UILabel!
    
    @IBOutlet weak var ExploreScoreCircle: UIView!
    
    @IBOutlet weak var ExploreScoretext: UILabel!
}
