//
//  SavedCell.swift
//  What2Eat
//
//  Created by admin68 on 04/11/24.
//

import UIKit

class SavedCell: UITableViewCell {

    

    @IBOutlet weak var SavedIcon: UIImageView!
    @IBOutlet weak var SavedLabel: UILabel!
}
