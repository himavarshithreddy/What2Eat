//
//  HighlightsCell.swift
//  What2Eat
//
//  Created by admin68 on 03/11/24.
//

import UIKit

class HighlightsCell: UITableViewCell {

    
    @IBOutlet weak var HighlightText: UILabel!
    @IBOutlet weak var iconImage: UIImageView!
    
}
